<div class="page-header bg-gradient-primary">
    <h3 class="page-title text-white">
        <span class="page-title-icon bg-gradient-danger text-white me-2">
            <i class="mdi mdi-file-document-box"></i>
        </span> Catatan Perjalanan
    </h3>
</div>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">

                    <h4 class="card-title text-primary">Data Catatan Perjalanan</h4>
                    <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                        <thead style="background-color: #da8cff; color: #fff;">
                            <tr>
                                <th style="background-color: #da8cff;">No</th>
                                <th style="background-color: #da8cff;">Tanggal</th>
                                <th style="background-color: #da8cff;">Jam</th>
                                <th style="background-color: #da8cff;">Lokasi</th>
                                <th style="background-color: #da8cff;">Suhu Tubuh</th>
                                <th style="background-color: #da8cff;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $no = 1;
                            $data = file('catatan.txt', FILE_IGNORE_NEW_LINES);
                            $user = $_SESSION['nik'] . "|" . $_SESSION['nama_lengkap'];
                            foreach ($data as $values) {
                                $dipisah = explode("|", $values);
                                @$key = $dipisah['1'] . "|" . $dipisah['2'];
                                if ($key == $user) {

                                    ?>
                                    <tr>
                                        <td style="background-color: #f2f2f2;">
                                            <?= $no++; ?>
                                        </td>
                                        <td>
                                            <?= $dipisah['3'] ?>
                                        </td>
                                        <td>
                                            <?= $dipisah['4'] ?>
                                        </td>
                                        <td>
                                            <?= $dipisah['5'] ?>
                                        </td>
                                        <td>
                                            <?= $dipisah['6'] ?> °C
                                            <?php
                                            $suhu_tubuh = (float) $dipisah['6']; // Konversi ke tipe data float untuk perbandingan angka
                                    
                                            if ($suhu_tubuh >= 30 && $suhu_tubuh <= 35) {
                                                echo "<span class='text-success font-weight-bold'> (Normal)</span>";
                                            } else if ($suhu_tubuh > 35 && $suhu_tubuh < 40) {
                                                echo "<span class='text-warning font-weight-bold'> (Tidak Normal)</span>";
                                            } else if ($suhu_tubuh >= 40) {
                                                echo "<span class='text-danger font-weight-bold'> (Segera periksa)</span>";
                                            }
                                            ?>
                                        </td>
                                       

                                        <td>
                                            <a href="?url=edit_catatan&id_catatan=<?= $dipisah['0'] ?>">
                                                <button class="btn btn-success btn-icon me-2"><i
                                                        class="mdi mdi-lead-pencil"></i></button>
                                            </a>
                                            <a onclick="return confirm('Apakah Anda Yakin Ingin Menghapus?')"
                                                href="hapus_catatan.php?id_catatan=<?= $dipisah['0'] ?>"
                                                class="btn btn-danger btn-icon">
                                                <button class="btn btn-danger btn-icon"><i class="mdi mdi-delete"></i></button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php }
                            } ?>
                        </tbody>
                    </table>
                    <a type="button" class="btn btn-info btn-icon-text me-2" href="cetak.php"
                        style="background-color: #da8cff; color: #fff;">Cetak <i
                            class="mdi mdi-printer btn-icon-append"></i></a>

                </div>
            </div>
        </div>
    </div>
</div>