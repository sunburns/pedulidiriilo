<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Text Bergerak</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .page-header {
            background-color: #007bff;
            color: #fff;
            padding: 15px;
            text-align: center;
        }

        .page-title {
            display: flex;
            align-items: center;
            font-size: 1.5rem;
        }

        .page-title-icon {
            border-radius: 50%;
            padding: 10px;
            background: #0056b3;
        }

        .mdi {
            color: #fff;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .card-body {
            padding: 30px;
        }

        .card-title {
            font-size: 2.5rem;
            text-align: center;
        }

        .fade-in {
            animation: fadeIn 1s ease-out infinite;
            opacity: 0;
        }

        .move-text {
            animation: moveText 2s linear infinite;
        }

        .d-flex {
            justify-content: center;
        }

        .flex-grow {
            flex-grow: 1;
        }

        h5 {
            font-size: 1.5rem;
            color: #007bff;
        }

        p {
            color: #6c757d;
            line-height: 1.6;
        }

        @keyframes moveText {
            0% {
                transform: translateX(0);
            }

            50% {
                transform: translateX(50px);
            }

            100% {
                transform: translateX(0);
            }
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <div class="page-header bg-gradient-primary">
        <h3 class="page-title text-white">
            <span class="page-title-icon bg-gradient-danger text-white me-2">
                <i class="mdi mdi-home"></i>
            </span> Beranda
        </h3>
    </div>
    <!-- <div class="page-header" .page-header { background-color: #ff6600; /* Change this color to your preference */ color:
        #fff; /* Adjust text color for contrast */ padding: 15px; text-align: center; }>
        <h3 class="page-title">
            <span class="page-title-icon bg-gradient-primary text-white me-2">
                <i class="mdi mdi-home"></i>
            </span> Beranda
        </h3>
    </div> -->
    <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">
                        <span class="fade-in">S</span>
                        <span class="fade-in">e</span>
                        <span class="fade-in">l</span>
                        <span class="fade-in">a</span>
                        <span class="fade-in">m</span>
                        <span class="fade-in">a</span>
                        <span class="fade-in">t</span>
                        <span class="fade-in">&nbsp;</span>
                        <span class="fade-in">D</span>
                        <span class="fade-in">a</span>
                        <span class="fade-in">t</span>
                        <span class="fade-in">a</span>
                        <span class="fade-in">n</span>
                        <span class="fade-in">g</span>
                        <span class="fade-in move-text">
                            <?php echo $_SESSION['nama_lengkap']; ?>
                        </span>
                    </h4>
                    <div class="d-flex mt-5 align-items-top">
                        <div class="mb-0 flex-grow">
                            <h5 class="me-2 mb-2" style="color: #da8cff;">Selamat datang di aplikasi PeduliDiri</h5>
                            <p class="mb-0 font-weight-light">Aplikasi ini digunakan sebagai panduan perjalanan selama
                                masa pandemi. Catatan perjalanan minimal mencakup tanggal perjalanan, waktu, lokasi yang
                                dikunjungi, dan suhu tubuh saat memasuki lokasi.</p>
                        </div>
                    </div>

                    <div class="mt-4">
                        <iframe width="1150" height="250" src="https://www.youtube.com/embed/R1Jt85fiDKI"
                            frameborder="0"
                            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                    </div>

                    <br><br><br>

                    <div class="col-xl-20 d-flex grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body animated fadeIn"
                                style="background-image: url('assets/images/2pacreja.jpg'); background-size: contain; border-radius: 50px; background-position: center;">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var fadeInElements = document.querySelectorAll('.fade-in');

            fadeInElements.forEach(function (element, index) {
                element.style.animationDelay = (index * 0.5) + 's';
            });
        });
    </script>
</body>

</html>